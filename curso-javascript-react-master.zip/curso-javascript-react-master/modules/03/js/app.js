
import { render } from './react-dom/index.js'
import Title from './components/title.js'

render(Title, window.container)