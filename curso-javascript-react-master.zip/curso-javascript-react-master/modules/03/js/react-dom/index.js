function render(component, container) {
  container.innerHTML = component
}

function hydrate() {

}

export {
  render,
  hydrate,
}