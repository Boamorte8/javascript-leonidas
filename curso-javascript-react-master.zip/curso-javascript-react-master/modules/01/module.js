export default function sayHey(name) {
  return `hola ${name}`
}

// export default sayHey