import { render } from './lib/react-dom.js'
import App from './components/app.js'

render(new App(), root)