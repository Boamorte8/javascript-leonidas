import styled from '../lib/styled-components.js'

export default styled.form`
  min-width: 320px;
  display: flex;
  gap: .5em;
`
