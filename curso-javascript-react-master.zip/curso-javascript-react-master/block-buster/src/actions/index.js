export const ADD_MOVIES = 'ADD_MOVIES'
export const SET_FILTER = 'SET_FILTER'
export const SEARCH_MOVIE = 'SEARCH_MOVIE'