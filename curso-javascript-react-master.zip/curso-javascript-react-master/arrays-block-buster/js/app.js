import movies from './movies.js'
import render from './render.js'
import './recommended.js'
import './search.js'
import './filter.js'
import './normalize.js'
render(movies)